#!/bin/bash
qmake-qt4 PREFIX=/usr
